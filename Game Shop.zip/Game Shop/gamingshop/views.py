from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from .models import *
# Create your views here.

def base(request):
    return render(request,'base.html')


def product_list(request):
    products = Product.objects.all()
    return render(request, 'home_product.html', {'products': products})


def product_detail(request, pk):
    product = Product.objects.get(pk=pk)
    return render(request, 'home_product_detail.html', {'product': product})


def shop_list(request):
    products = ShopProduct.objects.all()
    return render(request, 'shop.html', {'products': products})

@login_required
def view_cart(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render(request, 'cart.html', {'cart_items': cart_items, 'total_price': total_price})

def add_to_cart(request, product_id):
    product = ShopProduct.objects.get(id=product_id)
    cart_item,created = CartItem.objects.get_or_create(product=product, user=request.user)
    cart_item.quantity += 1
    cart_item.save()
    return redirect('view_cart')

@login_required
def remove_from_cart(request, item_id):
    cart_item = CartItem.objects.get(id=item_id)
    cart_item.delete()
    return redirect('view_cart')

def Logout(request):
    logout(request)
    return redirect('login')

def Login(request):
    if request.method == "GET":
        return render(request, 'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, "Login Success!")
            return redirect('user_profile')
        else:
            messages.error(request, "Username Or Password is Incorrect!")

@login_required
def user_profile(request):
    return render(request,'user_profile.html')

def register(request):
    if request.method == "GET":
        return render(request,'register.html')
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')
        if password == repassword:
            if User.objects.filter(username=username):
                messages.error(request, 'username already exists')
                return redirect('register')
            if User.objects.filter(email=email):
                messages.error(request, 'email already exists')
                return redirect('register')
            user = User.objects.create(
                username = username,
                email = email,
                password = make_password(password)
            )
            login(request, user)
            return redirect('/')
        else:
            messages.error(request, 'Password is not same!')
            return redirect(request,'register')
        
def search_bar(request):
    if request.method == "POST":
        searched=request.POST['searched']
        product=Product.objects.filter(name__contains=searched)
        shopproduct=ShopProduct.objects.filter(name__contains=searched)
        return render(request,'search_bar.html',{'searched': searched,'product':product,'shopproduct':shopproduct})
    else:
        return render(request,'search_bar.html',)
    
def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            send_mail(
                f'New contact from {form.cleaned_data["name"]}',
                form.cleaned_data['message'],
                settings.DEFAULT_FROM_EMAIL,
                [settings.ADMIN_EMAIL],
            )
            return render(request, 'contact/success.html')
    form = ContactForm()
    context = {'form': form}
    return render(request, 'contact.html', context)

def page_not_found(request):
    return render(request,'404.html')