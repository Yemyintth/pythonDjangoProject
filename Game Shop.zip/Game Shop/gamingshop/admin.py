from django.contrib import admin
from gamingshop.models import Product , ShopProduct, CartItem, ContactForm




# Register your models here.
admin.site.register(Product)
admin.site.register(ShopProduct)
admin.site.register(CartItem)
