from django.urls import path,re_path
from gamingshop.views import *
from django.conf.urls.static import static
from django.conf import settings

urlpatterns=[
    path('', product_list, name='product_list'),
    path('<int:pk>/', product_detail, name='product_detail'),
    path('shop/', shop_list, name='shop_list'),
    path('cart/',view_cart, name='view_cart'),
    path('add/<int:product_id>/',add_to_cart, name='add_to_cart'),
    path('remove/<int:item_id>/',remove_from_cart, name='remove_from_cart'),
    path('register/',register,name='register'),
    path('login/',Login, name='login'),
    path('logout/',Logout, name='logout'),
    path('user_profile/',user_profile,name='user_profile'),
    path('search_bar',search_bar,name='search-bar'),
    path('contact/',contact_view, name='contact'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
